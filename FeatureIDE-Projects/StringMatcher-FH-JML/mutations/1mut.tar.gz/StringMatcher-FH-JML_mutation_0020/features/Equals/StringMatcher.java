public  class   StringMatcher {
		
	/*@
	  @ requires \original;
	  @ ensures \original;
	  @*/
	public  boolean compare(String a, String b){
		//@set compare = a.equals(b);
		return a.equals(b);
	}
}