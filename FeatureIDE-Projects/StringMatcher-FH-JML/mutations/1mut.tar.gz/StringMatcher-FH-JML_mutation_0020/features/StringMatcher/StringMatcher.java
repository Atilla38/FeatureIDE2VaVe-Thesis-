
public  class   StringMatcher {

	public  StringMatcher(String mainText){

	}
	
	

	
}