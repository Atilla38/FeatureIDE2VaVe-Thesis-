import org.junit.Test;
import gov.nasa.jpf.util.test.TestJPF;
import static org.junit.Assert.*;
import gov.nasa.jpf.vm.Verify;
public  class StringMatcherTest extends TestJPF{
	@Test
	public void accountMC() {
		if (verifyNoPropertyViolation()) {
			matcher.compare("abc", "b");
			matcher.compare("abc", "ab");
			matcher.compare("abc", "bc");
			matcher.compare("ab", "abc");
			matcher.compare("bc", "abc");
			matcher.compare("b", "abc");
			matcher.compare("abc", "d");
			matcher.compare("abc", "def");
	}
		
	}
		}
	

