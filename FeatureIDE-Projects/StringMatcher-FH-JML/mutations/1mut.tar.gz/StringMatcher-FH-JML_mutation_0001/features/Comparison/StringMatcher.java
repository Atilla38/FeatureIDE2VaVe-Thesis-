
public  class  StringMatcher {

	//@public ghost boolean compare;
	int bla;
	


	
	/*@
	  @ requires a != null && b != null; 
	  @ ensures  \result <==> compare;
	  @*/
	public boolean compare(String a, String b){
	
		//@ set compare=true;
		return  false;
	}
	
}